            // Gabriel, Carol, Nulo
            var votoP  = [0, 0, 0];
            // Emanuelle, Daniel, Nulo
            var votoG  = [0, 0, 0];
            var branco = 0;
            var totalVotos = 0;

            form.addEventListener("submit", (event) => { 
                    event.preventDefault();
            });
            function fotop(form)
			{
			    var presidente  = form.presidente.value;
                
                switch (presidente){
                    case "69":
                        document.querySelector("#pres").innerHTML = "<img class='pres' src='candidatos/gabriel.jpg'>";
                        break;
                    case "96":
                        document.querySelector("#pres").innerHTML = "<img class='pres' src='candidatos/carol.jpg'>";
                        break;
                }
			}
			function fotog(form)
			{
			    var governador  = form.governador.value;

                switch (governador){
                    case "71":
                        document.querySelector("#gov").innerHTML = "<img class='gov' src='candidatos/emanuelle.jpg'>";
                        break;
                    case "24":
                        document.querySelector("#gov").innerHTML = "<img class='gov' src='candidatos/daniel.jpg'>";
                        break;
                }
			}
            function calcular(form){
                totalVotos  = totalVotos + 1;
                var presidente  = form.presidente.value;
                var governador  = form.governador.value;

                switch (presidente){
                    case "69":
                        alert("Voto de presidente para Gabriel! #Netuno");
                        votoP[0] = votoP[0] + 1;
                        break;
                    case "96":
                        alert("Voto de Presidente para Carol! #MadureiraGirl");
                        votoP[1] = votoP[1] + 1;
                        break;
                    default:
                        alert("Voto nulo para presidente!");
                        votoP[2] = votoP[2] + 1;
                }

                switch (governador){
                    case "71":
                        alert("Voto de governador para Emanuelle! #TeuC#");
                        votoG[0] = votoG[0] + 1;
                        break;
                    case "24":
                        alert("Voto de governador para Daniel! #AfroBege");
                        votoG[1] = votoG[1] + 1;
                        break;
                    default:
                        alert("Voto nulo para governador!");
                        votoG[2] = votoG[2] + 1;
                }
				form.presidente.value="";
				form.governador.value="";
				document.querySelector("#pres").innerHTML = "<img class='pres' src=''>";
				document.querySelector("#gov").innerHTML = "<img class='gov' src=''>";
				
            }
            
            function branco2(){
                alert("Voto em branco!");
                totalVotos = totalVotos + 1;
                branco = branco + 1;
            }

            function resultado(){
                alert(`Total de votos: ${totalVotos}
Total de votos em branco: ${branco}

Presidente:

Quantidade de votos para Gabriel: ${votoP[0]}
Quantidade de votos para Carol: ${votoP[1]}
Quantidade de votos Nulo: ${votoP[2]}

Governador:
Quantidade de votos para Emanuelle: ${votoG[0]}
Quantidade de votos para Daniel: ${votoG[1]}
Quantidade de votos Nulo: ${votoP[2]}`)
            }
